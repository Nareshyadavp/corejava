package com.inheritance.hierarchicalinheritance;

public class HierarchicalInheritance {

	public static void main(String[] args) {
		 
		Cat c=new Cat();  
		c.meow();  
		c.eat(); 
		//c.bark();//C.T.Error  

	}

}
