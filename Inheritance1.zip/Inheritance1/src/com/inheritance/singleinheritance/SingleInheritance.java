package com.inheritance.singleinheritance;

public class SingleInheritance {
	 public static void main(String args[]){  
		   Programmer p=new Programmer();  
		   System.out.println("programmer name is:"+p.ename);
		   System.out.println("programmer name is:"+p.eid);
		   System.out.println("Programmer salary is:"+p.esalary);  
		   System.out.println("Bonus of Programmer is:"+p.ebonus); 
		  		}  
}
