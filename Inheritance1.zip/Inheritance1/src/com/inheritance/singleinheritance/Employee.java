package com.inheritance.singleinheritance;
 public class Employee{ 
int eid=111;
String ename="ramu";
	 float esalary=40000.00f;  
	}  
	class Programmer extends Employee{  
	 int ebonus=10000;  
	
	}  