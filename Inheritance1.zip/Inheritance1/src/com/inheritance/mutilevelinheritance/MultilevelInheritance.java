package com.inheritance.mutilevelinheritance;

public class MultilevelInheritance {

	public static void main(String[] args) {
		BabyDog d=new BabyDog();  
		d.weep();  
		d.bark();  
		d.eat();  
	}

}
