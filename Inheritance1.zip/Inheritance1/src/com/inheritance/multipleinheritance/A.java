package com.inheritance.multipleinheritance;

public 	class A{  
		void msg(){System.out.println("Hello");}  
		}  
		class B{  
		void msg(){System.out.println("Welcome");}  
		}  
		//class C extends A,B{//suppose if it were{ }
		 
