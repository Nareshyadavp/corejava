package com.inheritance.multipleinheritance;

public class MultipleInheritance {

	public static void main(String[] args) {
		// C c=new C();  
		  // c.msg();//Now which msg() method would be invoked?  	 
}
}